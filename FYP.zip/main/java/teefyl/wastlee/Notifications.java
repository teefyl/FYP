package teefyl.wastlee;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.NotificationManager;
import android.support.v4.app.NotificationCompat;
import android.view.View;
import android.content.Context;

//import java.time.LocalDate;
//import java.time.ZoneId;
import java.util.Date;

public class Notifications{

    Date date = new Date();
    //LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
  //  int year  = localDate.getYear();
    //int month = localDate.getMonthValue();
//    int day   = localDate.getDayOfMonth();

   // String todaysDate = Integer.toString(day) + Integer.toString(month) + Integer.toString(year);

    //FoodItem expiringToday = DBManager.checkDate(todaysDate);
   // new AlertDialog.Builder(MainActivity.this).setTitle("Your Alert").setMessage("Your Message").setCancelable(false);





}